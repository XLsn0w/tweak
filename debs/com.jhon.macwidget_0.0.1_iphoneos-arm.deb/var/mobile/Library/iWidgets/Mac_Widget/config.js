// Enter the address of your RSS
var rssAddress = 'http://feeds.modmyi.com/home_all';
// Updated every X minutes.
var updateInterval = 15;
// Attempt to update when you do not have an internet connection.
var updateIntervalOff = 15;



// DO NOT EDIT !!!
var ShowPI = false;
// Limite du nombre de caractères affichés.
var LimitLetters = 250;
// Speical support for hebrew (if your main language is hebrew -> true, else -> false)
var hebrew = false;
// Do you want the widget to be right to left? (yes -> true, no -> false)
var rtl = false;

//VISIT OUR BLOG  : http://blogosquare.com