function init() {
refreshWeatherInfo();
setInterval("refreshWeatherInfo();", 3000);//Rafraîchisssement (ms)
}
function refreshWeatherInfo() {
if (window.XMLHttpRequest)
  {
  xmlhttp=new XMLHttpRequest();
  }
else
  {
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
/*---- WeatherIcon Caches .plist -----*/
xmlhttp.open("GET","/var/mobile/Library/Caches/com.ashman.LibWeather.cache.plist",false);

xmlhttp.send();
xmlDoc=xmlhttp.responseXML;
/*--------------------------------------------------------------------- GENERAL ---------------------------------------------------------------*/
/*-- VILLE ------------*/
document.getElementById("ville2").innerHTML= xmlDoc.getElementsByTagName("string")[0].childNodes[0].nodeValue;
/*-- TEMPS ACTUELLE --*/
document.getElementById("actutemp2").innerHTML= xmlDoc.getElementsByTagName("integer")[26].childNodes[0].nodeValue + "º";
/*-- TEMPS MAX/MIN ACTU --*/
document.getElementById("actumax2").innerHTML= xmlDoc.getElementsByTagName("integer")[4].childNodes[0].nodeValue + "º";
document.getElementById("actumin2").innerHTML= xmlDoc.getElementsByTagName("integer")[5].childNodes[0].nodeValue + "º";
/*-- DESC ACTUELLE ---*/
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='0') {document.getElementById("actudesc2").innerHTML="Tornado";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='1') {document.getElementById("actudesc2").innerHTML="Tropical storm";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='2') {document.getElementById("actudesc2").innerHTML="Hurricane";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='3') {document.getElementById("actudesc2").innerHTML="Severe thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='4') {document.getElementById("actudesc2").innerHTML="Thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='5') {document.getElementById("actudesc2").innerHTML="Mixed rain and snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='6') {document.getElementById("actudesc2").innerHTML="Mixed rain and sleet";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='7') {document.getElementById("actudesc2").innerHTML="Mixed snow and sleet";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='8') {document.getElementById("actudesc2").innerHTML="Freezing drizzle";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='9') {document.getElementById("actudesc2").innerHTML="Drizzle";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='10') {document.getElementById("actudesc2").innerHTML="Freezing rain";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='11') {document.getElementById("actudesc2").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='12') {document.getElementById("actudesc2").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='13') {document.getElementById("actudesc2").innerHTML="Snow flurries";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='14') {document.getElementById("actudesc2").innerHTML="Light snow showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='15') {document.getElementById("actudesc2").innerHTML="Blowing snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='16') {document.getElementById("actudesc2").innerHTML="Snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='17') {document.getElementById("actudesc2").innerHTML="Hail";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='18') {document.getElementById("actudesc2").innerHTML="Sleet";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='19') {document.getElementById("actudesc2").innerHTML="Dust";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='20') {document.getElementById("actudesc2").innerHTML="Foggy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='21') {document.getElementById("actudesc2").innerHTML="Haze";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='22') {document.getElementById("actudesc2").innerHTML="Smoky";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='23') {document.getElementById("actudesc2").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='24') {document.getElementById("actudesc2").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='25') {document.getElementById("actudesc2").innerHTML="Cold";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='26') {document.getElementById("actudesc2").innerHTML="Cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='27') {document.getElementById("actudesc2").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='28') {document.getElementById("actudesc2").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='29') {document.getElementById("actudesc2").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='30') {document.getElementById("actudesc2").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='31') {document.getElementById("actudesc2").innerHTML="Clear";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='32') {document.getElementById("actudesc2").innerHTML="Sunny";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='33') {document.getElementById("actudesc2").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='34') {document.getElementById("actudesc2").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='35') {document.getElementById("actudesc2").innerHTML="Mixed rain and hail";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='36') {document.getElementById("actudesc2").innerHTML="Hot";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='37') {document.getElementById("actudesc2").innerHTML="Isolated thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='38') {document.getElementById("actudesc2").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='39') {document.getElementById("actudesc2").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='40') {document.getElementById("actudesc2").innerHTML="Scattered showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='41') {document.getElementById("actudesc2").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='42') {document.getElementById("actudesc2").innerHTML="Scattered snow showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='43') {document.getElementById("actudesc2").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='44') {document.getElementById("actudesc2").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='45') {document.getElementById("actudesc2").innerHTML="Thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='46') {document.getElementById("actudesc2").innerHTML="Snow showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='47') {document.getElementById("actudesc2").innerHTML="Isolated thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='3200') {document.getElementById("actudesc2").innerHTML="Not available";}
/*-- ICONE ACTUELLE ----------*/
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='0') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/0.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='1') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/1.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='2') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/2.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='3') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/3.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='4') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/4.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='5') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/5.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='6') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/6.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='7') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/7.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='8') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/8.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='9') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/9.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='10') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/10.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='11') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/11.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='12') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/12.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='13') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/13.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='14') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/14.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='15') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/15.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='16') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/16.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='17') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/17.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='18') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/18.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='19') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/19.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='20') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/20.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='21') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/21.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='22') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/22.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='23') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/23.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='24') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/24.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='25') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/25.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='26') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/26.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='27') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/27.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='28') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/28.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='29') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/29.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='30') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/30.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='31') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/31.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='32') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/32.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='33') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/33.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='34') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/34.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='35') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/35.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='36') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/36.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='37') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/37.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='38') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/38.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='39') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/39.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='40') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/40.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='41') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/41.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='42') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/42.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='43') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/43.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='44') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/44.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='45') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/45.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='46') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/46.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='47') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/47.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='3200') {document.getElementById("actuicon2").innerHTML="<img class\=noiricon src=\"Library/Images/Icones/Noir_Blanc/na.png\">";}
}