function init2() {
refreshWeatherInfo2();
setInterval("refreshWeatherInfo2();", 3000);//Rafraîchisssement (ms)
}
function refreshWeatherInfo2() {
if (window.XMLHttpRequest)
  {
  xmlhttp=new XMLHttpRequest();
  }
else
  {
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
/*---- WeatherIcon Caches .plist -----*/
xmlhttp.open("GET","/var/mobile/Library/Caches/com.ashman.LibWeather.cache.plist",false);

xmlhttp.send();
xmlDoc=xmlhttp.responseXML;
/*--------------------------------------------------------------------- GENERAL ---------------------------------------------------------------*/
/*-- VILLE ------------*/
document.getElementById("ville").innerHTML= xmlDoc.getElementsByTagName("string")[0].childNodes[0].nodeValue;
/*-- TEMPS ACTUELLE --*/
document.getElementById("actutemp").innerHTML= xmlDoc.getElementsByTagName("integer")[26].childNodes[0].nodeValue + "º";
/*-- TEMPS MAX/MIN ACTU --*/
document.getElementById("actumax").innerHTML= xmlDoc.getElementsByTagName("integer")[4].childNodes[0].nodeValue + "º";
document.getElementById("actumin").innerHTML= xmlDoc.getElementsByTagName("integer")[5].childNodes[0].nodeValue + "º";
/*-- DESC ACTUELLE ---*/
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='0') {document.getElementById("actudesc").innerHTML="Tornado";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='1') {document.getElementById("actudesc").innerHTML="Tropical storm";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='2') {document.getElementById("actudesc").innerHTML="Hurricane";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='3') {document.getElementById("actudesc").innerHTML="Severe thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='4') {document.getElementById("actudesc").innerHTML="Thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='5') {document.getElementById("actudesc").innerHTML="Mixed rain and snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='6') {document.getElementById("actudesc").innerHTML="Mixed rain and sleet";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='7') {document.getElementById("actudesc").innerHTML="Mixed snow and sleet";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='8') {document.getElementById("actudesc").innerHTML="Freezing drizzle";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='9') {document.getElementById("actudesc").innerHTML="Drizzle";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='10') {document.getElementById("actudesc").innerHTML="Freezing rain";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='11') {document.getElementById("actudesc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='12') {document.getElementById("actudesc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='13') {document.getElementById("actudesc").innerHTML="Snow flurries";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='14') {document.getElementById("actudesc").innerHTML="Light snow showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='15') {document.getElementById("actudesc").innerHTML="Blowing snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='16') {document.getElementById("actudesc").innerHTML="Snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='17') {document.getElementById("actudesc").innerHTML="Hail";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='18') {document.getElementById("actudesc").innerHTML="Sleet";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='19') {document.getElementById("actudesc").innerHTML="Dust";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='20') {document.getElementById("actudesc").innerHTML="Foggy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='21') {document.getElementById("actudesc").innerHTML="Haze";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='22') {document.getElementById("actudesc").innerHTML="Smoky";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='23') {document.getElementById("actudesc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='24') {document.getElementById("actudesc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='25') {document.getElementById("actudesc").innerHTML="Cold";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='26') {document.getElementById("actudesc").innerHTML="Cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='27') {document.getElementById("actudesc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='28') {document.getElementById("actudesc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='29') {document.getElementById("actudesc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='30') {document.getElementById("actudesc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='31') {document.getElementById("actudesc").innerHTML="Clear";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='32') {document.getElementById("actudesc").innerHTML="Sunny";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='33') {document.getElementById("actudesc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='34') {document.getElementById("actudesc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='35') {document.getElementById("actudesc").innerHTML="Mixed rain and hail";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='36') {document.getElementById("actudesc").innerHTML="Hot";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='37') {document.getElementById("actudesc").innerHTML="Isolated thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='38') {document.getElementById("actudesc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='39') {document.getElementById("actudesc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='40') {document.getElementById("actudesc").innerHTML="Scattered showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='41') {document.getElementById("actudesc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='42') {document.getElementById("actudesc").innerHTML="Scattered snow showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='43') {document.getElementById("actudesc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='44') {document.getElementById("actudesc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='45') {document.getElementById("actudesc").innerHTML="Thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='46') {document.getElementById("actudesc").innerHTML="Snow showers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='47') {document.getElementById("actudesc").innerHTML="Isolated thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='3200') {document.getElementById("actudesc").innerHTML="Not available";}
/*-- ICONE ACTUELLE ----------*/
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='0') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/0.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='1') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/1.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='2') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/2.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='3') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/3.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='4') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/4.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='5') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/5.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='6') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/6.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='7') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/7.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='8') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/8.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='9') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/9.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='10') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/10.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='11') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/11.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='12') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/12.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='13') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/13.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='14') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/14.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='15') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/15.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='16') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/16.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='17') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/17.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='18') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/18.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='19') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/19.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='20') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/20.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='21') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/21.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='22') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/22.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='23') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/23.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='24') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/24.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='25') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/25.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='26') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/26.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='27') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/27.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='28') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/28.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='29') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/29.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='30') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/30.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='31') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/31.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='32') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/32.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='33') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/33.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='34') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/34.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='35') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/35.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='36') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/36.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='37') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/37.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='38') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/38.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='39') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/39.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='40') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/40.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='41') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/41.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='42') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/42.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='43') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/43.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='44') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/44.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='45') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/45.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='46') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/46.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='47') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/47.png\">";}
if (xmlDoc.getElementsByTagName("integer")[1].childNodes[0].nodeValue =='3200') {document.getElementById("actuicon").innerHTML="<img class\=bigicon src=\"Library/Images/Icones/Grandes/no.png\">";}
/*---------------------------------------------------------------------- JOUR 0 ---------------------------------------------------------------*/
/*-- NOM 0 --*/
if (xmlDoc.getElementsByTagName("integer")[3].childNodes[0].nodeValue =='0') {document.getElementById("j0").innerHTML="Sunday";}
if (xmlDoc.getElementsByTagName("integer")[3].childNodes[0].nodeValue =='1') {document.getElementById("j0").innerHTML="Monday";}
if (xmlDoc.getElementsByTagName("integer")[3].childNodes[0].nodeValue =='2') {document.getElementById("j0").innerHTML="Tuesday";}
if (xmlDoc.getElementsByTagName("integer")[3].childNodes[0].nodeValue =='3') {document.getElementById("j0").innerHTML="Wednesday";}
if (xmlDoc.getElementsByTagName("integer")[3].childNodes[0].nodeValue =='4') {document.getElementById("j0").innerHTML="Thursday";}
if (xmlDoc.getElementsByTagName("integer")[3].childNodes[0].nodeValue =='5') {document.getElementById("j0").innerHTML="Friday";}
if (xmlDoc.getElementsByTagName("integer")[3].childNodes[0].nodeValue =='6') {document.getElementById("j0").innerHTML="Saturday";}
/*-- TEMPS MAX/MIN 0 --*/
document.getElementById("j0max").innerHTML= xmlDoc.getElementsByTagName("integer")[4].childNodes[0].nodeValue + "º";
document.getElementById("j0min").innerHTML= xmlDoc.getElementsByTagName("integer")[5].childNodes[0].nodeValue + "º";
/*-- DESC 0 -----------*/
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='0') {document.getElementById("j0desc").innerHTML="Tornado";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='1') {document.getElementById("j0desc").innerHTML="Tropical storm";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='2') {document.getElementById("j0desc").innerHTML="Hurricane";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='3') {document.getElementById("j0desc").innerHTML="Severe thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='4') {document.getElementById("j0desc").innerHTML="Thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='5') {document.getElementById("j0desc").innerHTML="Mixed rain and snow";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='6') {document.getElementById("j0desc").innerHTML="Mixed rain and sleet";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='7') {document.getElementById("j0desc").innerHTML="Mixed snow and sleet";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='8') {document.getElementById("j0desc").innerHTML="Freezing drizzle";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='9') {document.getElementById("j0desc").innerHTML="Drizzle";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='10') {document.getElementById("j0desc").innerHTML="Freezing rain";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='11') {document.getElementById("j0desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='12') {document.getElementById("j0desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='13') {document.getElementById("j0desc").innerHTML="Snow flurries";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='14') {document.getElementById("j0desc").innerHTML="Light snow showers";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='15') {document.getElementById("j0desc").innerHTML="Blowing snow";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='16') {document.getElementById("j0desc").innerHTML="Snow";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='17') {document.getElementById("j0desc").innerHTML="Hail";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='18') {document.getElementById("j0desc").innerHTML="Sleet";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='19') {document.getElementById("j0desc").innerHTML="Dust";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='20') {document.getElementById("j0desc").innerHTML="Foggy";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='21') {document.getElementById("j0desc").innerHTML="Haze";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='22') {document.getElementById("j0desc").innerHTML="Smoky";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='23') {document.getElementById("j0desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='24') {document.getElementById("j0desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='25') {document.getElementById("j0desc").innerHTML="Cold";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='26') {document.getElementById("j0desc").innerHTML="Cloudy";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='27') {document.getElementById("j0desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='28') {document.getElementById("j0desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='29') {document.getElementById("j0desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='30') {document.getElementById("j0desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='31') {document.getElementById("j0desc").innerHTML="Clear";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='32') {document.getElementById("j0desc").innerHTML="Sunny";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='33') {document.getElementById("j0desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='34') {document.getElementById("j0desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='35') {document.getElementById("j0desc").innerHTML="Mixed rain and hail";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='36') {document.getElementById("j0desc").innerHTML="Hot";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='37') {document.getElementById("j0desc").innerHTML="Isolated thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='38') {document.getElementById("j0desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='39') {document.getElementById("j0desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='40') {document.getElementById("j0desc").innerHTML="Scattered showers";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='41') {document.getElementById("j0desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='42') {document.getElementById("j0desc").innerHTML="Scattered snow showers";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='43') {document.getElementById("j0desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='44') {document.getElementById("j0desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='45') {document.getElementById("j0desc").innerHTML="Thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='46') {document.getElementById("j0desc").innerHTML="Snow showers";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='47') {document.getElementById("j0desc").innerHTML="Isolated thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='3200') {document.getElementById("j0desc").innerHTML="Not available";}
/*-- ICONE 0 ----------*/
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='0') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/0.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='1') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/1.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='2') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/2.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='3') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/3.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='4') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/4.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='5') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/5.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='6') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/6.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='7') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/7.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='8') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/8.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='9') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/9.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='10') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/10.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='11') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/11.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='12') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/12.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='13') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/13.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='14') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/14.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='15') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/15.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='16') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/16.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='17') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/17.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='18') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/18.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='19') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/19.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='20') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/20.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='21') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/21.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='22') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/22.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='23') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/23.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='24') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/24.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='25') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/25.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='26') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/26.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='27') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/27.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='28') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/28.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='29') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/29.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='30') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/30.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='31') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/31.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='32') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/32.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='33') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/33.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='34') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/34.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='35') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/35.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='36') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/36.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='37') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/37.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='38') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/38.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='39') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/39.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='40') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/40.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='41') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/41.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='42') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/42.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='43') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/43.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='44') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/44.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='45') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/45.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='46') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/46.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='47') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/47.png\">";}
if (xmlDoc.getElementsByTagName("integer")[2].childNodes[0].nodeValue =='3200') {document.getElementById("j0icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/no.png\">";}
/*---------------------------------------------------------------------- JOUR 1 ---------------------------------------------------------------*/
/*-- NOM 1 ------------*/
if (xmlDoc.getElementsByTagName("integer")[7].childNodes[0].nodeValue =='0') {document.getElementById("j1").innerHTML="Sunday";}
if (xmlDoc.getElementsByTagName("integer")[7].childNodes[0].nodeValue =='1') {document.getElementById("j1").innerHTML="Monday";}
if (xmlDoc.getElementsByTagName("integer")[7].childNodes[0].nodeValue =='2') {document.getElementById("j1").innerHTML="Tuesday";}
if (xmlDoc.getElementsByTagName("integer")[7].childNodes[0].nodeValue =='3') {document.getElementById("j1").innerHTML="Wednesday";}
if (xmlDoc.getElementsByTagName("integer")[7].childNodes[0].nodeValue =='4') {document.getElementById("j1").innerHTML="Thursday";}
if (xmlDoc.getElementsByTagName("integer")[7].childNodes[0].nodeValue =='5') {document.getElementById("j1").innerHTML="Friday";}
if (xmlDoc.getElementsByTagName("integer")[7].childNodes[0].nodeValue =='6') {document.getElementById("j1").innerHTML="Saturday";}
/*-- TEMPS MAX/MIN 1 --*/
document.getElementById("j1max").innerHTML= xmlDoc.getElementsByTagName("integer")[8].childNodes[0].nodeValue + "º";
document.getElementById("j1min").innerHTML= xmlDoc.getElementsByTagName("integer")[9].childNodes[0].nodeValue + "º";
/*-- DESC 1 -----------*/
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='0') {document.getElementById("j1desc").innerHTML="Tornado";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='1') {document.getElementById("j1desc").innerHTML="Tropical storm";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='2') {document.getElementById("j1desc").innerHTML="Hurricane";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='3') {document.getElementById("j1desc").innerHTML="Severe thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='4') {document.getElementById("j1desc").innerHTML="Thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='5') {document.getElementById("j1desc").innerHTML="Mixed rain and snow";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='6') {document.getElementById("j1desc").innerHTML="Mixed rain and sleet";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='7') {document.getElementById("j1desc").innerHTML="Mixed snow and sleet";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='8') {document.getElementById("j1desc").innerHTML="Freezing drizzle";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='9') {document.getElementById("j1desc").innerHTML="Drizzle";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='10') {document.getElementById("j1desc").innerHTML="Freezing rain";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='11') {document.getElementById("j1desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='12') {document.getElementById("j1desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='13') {document.getElementById("j1desc").innerHTML="Snow flurries";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='14') {document.getElementById("j1desc").innerHTML="Light snow showers";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='15') {document.getElementById("j1desc").innerHTML="Blowing snow";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='16') {document.getElementById("j1desc").innerHTML="Snow";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='17') {document.getElementById("j1desc").innerHTML="Hail";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='18') {document.getElementById("j1desc").innerHTML="Sleet";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='19') {document.getElementById("j1desc").innerHTML="Dust";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='20') {document.getElementById("j1desc").innerHTML="Foggy";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='21') {document.getElementById("j1desc").innerHTML="Haze";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='22') {document.getElementById("j1desc").innerHTML="Smoky";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='23') {document.getElementById("j1desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='24') {document.getElementById("j1desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='25') {document.getElementById("j1desc").innerHTML="Cold";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='26') {document.getElementById("j1desc").innerHTML="Cloudy";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='27') {document.getElementById("j1desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='28') {document.getElementById("j1desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='29') {document.getElementById("j1desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='30') {document.getElementById("j1desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='31') {document.getElementById("j1desc").innerHTML="Clear";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='32') {document.getElementById("j1desc").innerHTML="Sunny";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='33') {document.getElementById("j1desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='34') {document.getElementById("j1desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='35') {document.getElementById("j1desc").innerHTML="Mixed rain and hail";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='36') {document.getElementById("j1desc").innerHTML="Hot";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='37') {document.getElementById("j1desc").innerHTML="Isolated thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='38') {document.getElementById("j1desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='39') {document.getElementById("j1desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='40') {document.getElementById("j1desc").innerHTML="Scattered showers";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='41') {document.getElementById("j1desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='42') {document.getElementById("j1desc").innerHTML="Scattered snow showers";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='43') {document.getElementById("j1desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='44') {document.getElementById("j1desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='45') {document.getElementById("j1desc").innerHTML="Thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='46') {document.getElementById("j1desc").innerHTML="Snow showers";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='47') {document.getElementById("j1desc").innerHTML="Isolated thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='3200') {document.getElementById("j1desc").innerHTML="Not available";}
/*-- ICONE 1 ----------*/
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='0') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/0.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='1') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/1.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='2') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/2.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='3') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/3.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='4') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/4.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='5') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/5.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='6') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/6.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='7') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/7.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='8') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/8.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='9') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/9.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='10') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/10.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='11') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/11.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='12') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/12.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='13') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/13.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='14') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/14.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='15') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/15.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='16') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/16.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='17') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/17.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='18') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/18.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='19') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/19.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='20') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/20.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='21') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/21.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='22') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/22.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='23') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/23.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='24') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/24.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='25') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/25.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='26') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/26.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='27') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/27.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='28') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/28.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='29') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/29.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='30') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/30.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='31') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/31.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='32') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/32.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='33') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/33.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='34') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/34.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='35') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/35.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='36') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/36.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='37') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/37.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='38') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/38.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='39') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/39.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='40') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/40.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='41') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/41.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='42') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/42.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='43') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/43.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='44') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/44.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='45') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/45.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='46') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/46.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='47') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/47.png\">";}
if (xmlDoc.getElementsByTagName("integer")[6].childNodes[0].nodeValue =='3200') {document.getElementById("j1icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/no.png\">";}
/*---------------------------------------------------------------------- JOUR 2 ---------------------------------------------------------------*/
/*-- NOM 2 ------------*/
if (xmlDoc.getElementsByTagName("integer")[11].childNodes[0].nodeValue =='0') {document.getElementById("j2").innerHTML="Sunday";}
if (xmlDoc.getElementsByTagName("integer")[11].childNodes[0].nodeValue =='1') {document.getElementById("j2").innerHTML="Monday";}
if (xmlDoc.getElementsByTagName("integer")[11].childNodes[0].nodeValue =='2') {document.getElementById("j2").innerHTML="Tuesday";}
if (xmlDoc.getElementsByTagName("integer")[11].childNodes[0].nodeValue =='3') {document.getElementById("j2").innerHTML="Wednesday";}
if (xmlDoc.getElementsByTagName("integer")[11].childNodes[0].nodeValue =='4') {document.getElementById("j2").innerHTML="Thursday";}
if (xmlDoc.getElementsByTagName("integer")[11].childNodes[0].nodeValue =='5') {document.getElementById("j2").innerHTML="Friday";}
if (xmlDoc.getElementsByTagName("integer")[11].childNodes[0].nodeValue =='6') {document.getElementById("j2").innerHTML="Saturday";}
/*-- TEMPS MAX/MIN 2 --*/
document.getElementById("j2max").innerHTML= xmlDoc.getElementsByTagName("integer")[12].childNodes[0].nodeValue + "º";
document.getElementById("j2min").innerHTML= xmlDoc.getElementsByTagName("integer")[13].childNodes[0].nodeValue + "º";
/*-- DESC 2 -----------*/
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='0') {document.getElementById("j2desc").innerHTML="Tornado";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='1') {document.getElementById("j2desc").innerHTML="Tropical storm";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='2') {document.getElementById("j2desc").innerHTML="Hurricane";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='3') {document.getElementById("j2desc").innerHTML="Severe thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='4') {document.getElementById("j2desc").innerHTML="Thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='5') {document.getElementById("j2desc").innerHTML="Mixed rain and snow";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='6') {document.getElementById("j2desc").innerHTML="Mixed rain and sleet";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='7') {document.getElementById("j2desc").innerHTML="Mixed snow and sleet";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='8') {document.getElementById("j2desc").innerHTML="Freezing drizzle";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='9') {document.getElementById("j2desc").innerHTML="Drizzle";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='10') {document.getElementById("j2desc").innerHTML="Freezing rain";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='11') {document.getElementById("j2desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='12') {document.getElementById("j2desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='13') {document.getElementById("j2desc").innerHTML="Snow flurries";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='14') {document.getElementById("j2desc").innerHTML="Light snow showers";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='15') {document.getElementById("j2desc").innerHTML="Blowing snow";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='16') {document.getElementById("j2desc").innerHTML="Snow";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='17') {document.getElementById("j2desc").innerHTML="Hail";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='18') {document.getElementById("j2desc").innerHTML="Sleet";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='19') {document.getElementById("j2desc").innerHTML="Dust";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='20') {document.getElementById("j2desc").innerHTML="Foggy";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='21') {document.getElementById("j2desc").innerHTML="Haze";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='22') {document.getElementById("j2desc").innerHTML="Smoky";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='23') {document.getElementById("j2desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='24') {document.getElementById("j2desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='25') {document.getElementById("j2desc").innerHTML="Cold";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='26') {document.getElementById("j2desc").innerHTML="Cloudy";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='27') {document.getElementById("j2desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='28') {document.getElementById("j2desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='29') {document.getElementById("j2desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='30') {document.getElementById("j2desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='31') {document.getElementById("j2desc").innerHTML="Clear";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='32') {document.getElementById("j2desc").innerHTML="Sunny";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='33') {document.getElementById("j2desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='34') {document.getElementById("j2desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='35') {document.getElementById("j2desc").innerHTML="Mixed rain and hail";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='36') {document.getElementById("j2desc").innerHTML="Hot";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='37') {document.getElementById("j2desc").innerHTML="Isolated thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='38') {document.getElementById("j2desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='39') {document.getElementById("j2desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='40') {document.getElementById("j2desc").innerHTML="Scattered showers";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='41') {document.getElementById("j2desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='42') {document.getElementById("j2desc").innerHTML="Scattered snow showers";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='43') {document.getElementById("j2desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='44') {document.getElementById("j2desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='45') {document.getElementById("j2desc").innerHTML="Thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='46') {document.getElementById("j2desc").innerHTML="Snow showers";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='47') {document.getElementById("j2desc").innerHTML="Isolated thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='3200') {document.getElementById("j2desc").innerHTML="Not available";}
/*-- ICONE 2 ----------*/
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='0') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/0.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='1') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/1.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='2') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/2.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='3') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/3.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='4') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/4.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='5') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/5.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='6') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/6.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='7') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/7.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='8') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/8.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='9') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/9.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='10') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/10.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='11') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/11.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='12') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/12.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='13') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/13.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='14') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/14.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='15') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/15.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='16') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/16.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='17') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/17.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='18') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/18.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='19') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/19.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='20') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/20.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='21') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/21.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='22') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/22.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='23') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/23.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='24') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/24.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='25') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/25.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='26') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/26.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='27') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/27.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='28') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/28.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='29') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/29.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='30') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/30.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='31') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/31.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='32') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/32.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='33') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/33.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='34') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/34.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='35') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/35.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='36') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/36.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='37') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/37.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='38') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/38.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='39') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/39.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='40') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/40.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='41') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/41.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='42') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/42.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='43') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/43.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='44') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/44.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='45') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/45.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='46') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/46.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='47') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/47.png\">";}
if (xmlDoc.getElementsByTagName("integer")[10].childNodes[0].nodeValue =='3200') {document.getElementById("j2icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/no.png\">";}
/*---------------------------------------------------------------------- JOUR 3 ---------------------------------------------------------------*/
/*-- NOM 3 --*/
if (xmlDoc.getElementsByTagName("integer")[15].childNodes[0].nodeValue =='0') {document.getElementById("j3").innerHTML="Sunday";}
if (xmlDoc.getElementsByTagName("integer")[15].childNodes[0].nodeValue =='1') {document.getElementById("j3").innerHTML="Monday";}
if (xmlDoc.getElementsByTagName("integer")[15].childNodes[0].nodeValue =='2') {document.getElementById("j3").innerHTML="Tuesday";}
if (xmlDoc.getElementsByTagName("integer")[15].childNodes[0].nodeValue =='3') {document.getElementById("j3").innerHTML="Wednesday";}
if (xmlDoc.getElementsByTagName("integer")[15].childNodes[0].nodeValue =='4') {document.getElementById("j3").innerHTML="Thursday";}
if (xmlDoc.getElementsByTagName("integer")[15].childNodes[0].nodeValue =='5') {document.getElementById("j3").innerHTML="Friday";}
if (xmlDoc.getElementsByTagName("integer")[15].childNodes[0].nodeValue =='6') {document.getElementById("j3").innerHTML="Saturday";}
/*-- TEMPS MAX/MIN 3 --*/
document.getElementById("j3max").innerHTML= xmlDoc.getElementsByTagName("integer")[16].childNodes[0].nodeValue + "º";
document.getElementById("j3min").innerHTML= xmlDoc.getElementsByTagName("integer")[17].childNodes[0].nodeValue + "º";
/*-- DESC 3 -----------*/
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='0') {document.getElementById("j3desc").innerHTML="Tornado";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='1') {document.getElementById("j3desc").innerHTML="Tropical storm";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='2') {document.getElementById("j3desc").innerHTML="Hurricane";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='3') {document.getElementById("j3desc").innerHTML="Severe thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='4') {document.getElementById("j3desc").innerHTML="Thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='5') {document.getElementById("j3desc").innerHTML="Mixed rain and snow";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='6') {document.getElementById("j3desc").innerHTML="Mixed rain and sleet";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='7') {document.getElementById("j3desc").innerHTML="Mixed snow and sleet";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='8') {document.getElementById("j3desc").innerHTML="Freezing drizzle";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='9') {document.getElementById("j3desc").innerHTML="Drizzle";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='10') {document.getElementById("j3desc").innerHTML="Freezing rain";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='11') {document.getElementById("j3desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='12') {document.getElementById("j3desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='13') {document.getElementById("j3desc").innerHTML="Snow flurries";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='14') {document.getElementById("j3desc").innerHTML="Light snow showers";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='15') {document.getElementById("j3desc").innerHTML="Blowing snow";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='16') {document.getElementById("j3desc").innerHTML="Snow";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='17') {document.getElementById("j3desc").innerHTML="Hail";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='18') {document.getElementById("j3desc").innerHTML="Sleet";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='19') {document.getElementById("j3desc").innerHTML="Dust";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='20') {document.getElementById("j3desc").innerHTML="Foggy";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='21') {document.getElementById("j3desc").innerHTML="Haze";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='22') {document.getElementById("j3desc").innerHTML="Smoky";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='23') {document.getElementById("j3desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='24') {document.getElementById("j3desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='25') {document.getElementById("j3desc").innerHTML="Cold";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='26') {document.getElementById("j3desc").innerHTML="Cloudy";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='27') {document.getElementById("j3desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='28') {document.getElementById("j3desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='29') {document.getElementById("j3desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='30') {document.getElementById("j3desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='31') {document.getElementById("j3desc").innerHTML="Clear";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='32') {document.getElementById("j3desc").innerHTML="Sunny";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='33') {document.getElementById("j3desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='34') {document.getElementById("j3desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='35') {document.getElementById("j3desc").innerHTML="Mixed rain and hail";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='36') {document.getElementById("j3desc").innerHTML="Hot";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='37') {document.getElementById("j3desc").innerHTML="Isolated thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='38') {document.getElementById("j3desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='39') {document.getElementById("j3desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='40') {document.getElementById("j3desc").innerHTML="Scattered showers";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='41') {document.getElementById("j3desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='42') {document.getElementById("j3desc").innerHTML="Scattered snow showers";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='43') {document.getElementById("j3desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='44') {document.getElementById("j3desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='45') {document.getElementById("j3desc").innerHTML="Thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='46') {document.getElementById("j3desc").innerHTML="Snow showers";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='47') {document.getElementById("j3desc").innerHTML="Isolated thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='3200') {document.getElementById("j3desc").innerHTML="Not available";}
/*-- ICONE 3 ----------*/
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='0') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/0.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='1') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/1.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='2') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/2.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='3') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/3.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='4') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/4.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='5') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/5.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='6') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/6.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='7') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/7.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='8') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/8.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='9') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/9.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='10') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/10.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='11') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/11.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='12') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/12.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='13') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/13.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='14') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/14.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='15') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/15.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='16') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/16.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='17') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/17.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='18') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/18.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='19') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/19.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='20') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/20.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='21') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/21.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='22') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/22.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='23') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/23.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='24') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/24.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='25') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/25.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='26') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/26.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='27') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/27.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='28') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/28.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='29') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/29.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='30') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/30.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='31') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/31.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='32') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/32.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='33') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/33.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='34') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/34.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='35') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/35.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='36') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/36.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='37') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/37.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='38') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/38.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='39') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/39.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='40') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/40.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='41') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/41.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='42') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/42.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='43') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/43.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='44') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/44.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='45') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/45.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='46') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/46.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='47') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/47.png\">";}
if (xmlDoc.getElementsByTagName("integer")[14].childNodes[0].nodeValue =='3200') {document.getElementById("j3icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/no.png\">";}
/*---------------------------------------------------------------------- JOUR 4 ---------------------------------------------------------------*/
/*-- NOM 4 --*/
if (xmlDoc.getElementsByTagName("integer")[19].childNodes[0].nodeValue =='0') {document.getElementById("j4").innerHTML="Sunday";}
if (xmlDoc.getElementsByTagName("integer")[19].childNodes[0].nodeValue =='1') {document.getElementById("j4").innerHTML="Monday";}
if (xmlDoc.getElementsByTagName("integer")[19].childNodes[0].nodeValue =='2') {document.getElementById("j4").innerHTML="Tuesday";}
if (xmlDoc.getElementsByTagName("integer")[19].childNodes[0].nodeValue =='3') {document.getElementById("j4").innerHTML="Wednesday";}
if (xmlDoc.getElementsByTagName("integer")[19].childNodes[0].nodeValue =='4') {document.getElementById("j4").innerHTML="Thursday";}
if (xmlDoc.getElementsByTagName("integer")[19].childNodes[0].nodeValue =='5') {document.getElementById("j4").innerHTML="Friday";}
if (xmlDoc.getElementsByTagName("integer")[19].childNodes[0].nodeValue =='6') {document.getElementById("j4").innerHTML="Saturday";}
/*-- TEMPS MAX/MIN 4 --*/
document.getElementById("j4max").innerHTML= xmlDoc.getElementsByTagName("integer")[20].childNodes[0].nodeValue + "º";
document.getElementById("j4min").innerHTML= xmlDoc.getElementsByTagName("integer")[21].childNodes[0].nodeValue + "º";
/*-- DESC 4 -----------*/
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='0') {document.getElementById("j4desc").innerHTML="Tornado";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='1') {document.getElementById("j4desc").innerHTML="Tropical storm";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='2') {document.getElementById("j4desc").innerHTML="Hurricane";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='3') {document.getElementById("j4desc").innerHTML="Severe thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='4') {document.getElementById("j4desc").innerHTML="Thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='5') {document.getElementById("j4desc").innerHTML="Mixed rain and snow";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='6') {document.getElementById("j4desc").innerHTML="Mixed rain and sleet";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='7') {document.getElementById("j4desc").innerHTML="Mixed snow and sleet";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='8') {document.getElementById("j4desc").innerHTML="Freezing drizzle";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='9') {document.getElementById("j4desc").innerHTML="Drizzle";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='10') {document.getElementById("j4desc").innerHTML="Freezing rain";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='11') {document.getElementById("j4desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='12') {document.getElementById("j4desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='13') {document.getElementById("j4desc").innerHTML="Snow flurries";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='14') {document.getElementById("j4desc").innerHTML="Light snow showers";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='15') {document.getElementById("j4desc").innerHTML="Blowing snow";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='16') {document.getElementById("j4desc").innerHTML="Snow";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='17') {document.getElementById("j4desc").innerHTML="Hail";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='18') {document.getElementById("j4desc").innerHTML="Sleet";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='19') {document.getElementById("j4desc").innerHTML="Dust";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='20') {document.getElementById("j4desc").innerHTML="Foggy";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='21') {document.getElementById("j4desc").innerHTML="Haze";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='22') {document.getElementById("j4desc").innerHTML="Smoky";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='23') {document.getElementById("j4desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='24') {document.getElementById("j4desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='25') {document.getElementById("j4desc").innerHTML="Cold";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='26') {document.getElementById("j4desc").innerHTML="Cloudy";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='27') {document.getElementById("j4desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='28') {document.getElementById("j4desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='29') {document.getElementById("j4desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='30') {document.getElementById("j4desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='31') {document.getElementById("j4desc").innerHTML="Clear";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='32') {document.getElementById("j4desc").innerHTML="Sunny";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='33') {document.getElementById("j4desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='34') {document.getElementById("j4desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='35') {document.getElementById("j4desc").innerHTML="Mixed rain and hail";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='36') {document.getElementById("j4desc").innerHTML="Hot";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='37') {document.getElementById("j4desc").innerHTML="Isolated thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='38') {document.getElementById("j4desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='39') {document.getElementById("j4desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='40') {document.getElementById("j4desc").innerHTML="Scattered showers";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='41') {document.getElementById("j4desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='42') {document.getElementById("j4desc").innerHTML="Scattered snow showers";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='43') {document.getElementById("j4desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='44') {document.getElementById("j4desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='45') {document.getElementById("j4desc").innerHTML="Thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='46') {document.getElementById("j4desc").innerHTML="Snow showers";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='47') {document.getElementById("j4desc").innerHTML="Isolated thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='3200') {document.getElementById("j4desc").innerHTML="Not available";}
/*-- ICONE 4 ----------*/
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='0') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/0.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='1') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/1.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='2') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/2.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='3') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/3.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='4') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/4.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='5') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/5.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='6') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/6.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='7') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/7.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='8') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/8.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='9') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/9.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='10') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/10.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='11') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/11.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='12') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/12.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='13') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/13.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='14') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/14.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='15') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/15.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='16') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/16.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='17') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/17.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='18') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/18.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='19') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/19.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='20') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/20.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='21') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/21.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='22') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/22.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='23') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/23.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='24') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/24.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='25') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/25.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='26') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/26.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='27') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/27.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='28') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/28.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='29') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/29.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='30') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/30.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='31') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/31.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='32') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/32.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='33') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/33.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='34') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/34.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='35') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/35.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='36') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/36.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='37') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/37.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='38') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/38.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='39') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/39.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='40') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/40.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='41') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/41.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='42') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/42.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='43') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/43.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='44') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/44.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='45') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/45.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='46') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/46.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='47') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/47.png\">";}
if (xmlDoc.getElementsByTagName("integer")[18].childNodes[0].nodeValue =='3200') {document.getElementById("j4icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/no.png\">";}
/*---------------------------------------------------------------------- JOUR 5 ---------------------------------------------------------------*/
/*-- NOM 5 --*/
if (xmlDoc.getElementsByTagName("integer")[23].childNodes[0].nodeValue =='0') {document.getElementById("j5").innerHTML="Sunday";}
if (xmlDoc.getElementsByTagName("integer")[23].childNodes[0].nodeValue =='1') {document.getElementById("j5").innerHTML="Monday";}
if (xmlDoc.getElementsByTagName("integer")[23].childNodes[0].nodeValue =='2') {document.getElementById("j5").innerHTML="Tuesday";}
if (xmlDoc.getElementsByTagName("integer")[23].childNodes[0].nodeValue =='3') {document.getElementById("j5").innerHTML="Wednesday";}
if (xmlDoc.getElementsByTagName("integer")[23].childNodes[0].nodeValue =='4') {document.getElementById("j5").innerHTML="Thursday";}
if (xmlDoc.getElementsByTagName("integer")[23].childNodes[0].nodeValue =='5') {document.getElementById("j5").innerHTML="Friday";}
if (xmlDoc.getElementsByTagName("integer")[23].childNodes[0].nodeValue =='6') {document.getElementById("j5").innerHTML="Saturday";}
/*-- TEMPS MAX/MIN 5 --*/
document.getElementById("j5max").innerHTML= xmlDoc.getElementsByTagName("integer")[24].childNodes[0].nodeValue + "º";
document.getElementById("j5min").innerHTML= xmlDoc.getElementsByTagName("integer")[25].childNodes[0].nodeValue + "º";
/*-- DESC 5 -----------*/
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='0') {document.getElementById("j5desc").innerHTML="Tornado";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='1') {document.getElementById("j5desc").innerHTML="Tropical storm";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='2') {document.getElementById("j5desc").innerHTML="Hurricane";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='3') {document.getElementById("j5desc").innerHTML="Severe thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='4') {document.getElementById("j5desc").innerHTML="Thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='5') {document.getElementById("j5desc").innerHTML="Mixed rain and snow";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='6') {document.getElementById("j5desc").innerHTML="Mixed rain and sleet";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='7') {document.getElementById("j5desc").innerHTML="Mixed snow and sleet";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='8') {document.getElementById("j5desc").innerHTML="Freezing drizzle";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='9') {document.getElementById("j5desc").innerHTML="Drizzle";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='10') {document.getElementById("j5desc").innerHTML="Freezing rain";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='11') {document.getElementById("j5desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='12') {document.getElementById("j5desc").innerHTML="Showers";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='13') {document.getElementById("j5desc").innerHTML="Snow flurries";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='14') {document.getElementById("j5desc").innerHTML="Light snow showers";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='15') {document.getElementById("j5desc").innerHTML="Blowing snow";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='16') {document.getElementById("j5desc").innerHTML="Snow";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='17') {document.getElementById("j5desc").innerHTML="Hail";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='18') {document.getElementById("j5desc").innerHTML="Sleet";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='19') {document.getElementById("j5desc").innerHTML="Dust";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='20') {document.getElementById("j5desc").innerHTML="Foggy";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='21') {document.getElementById("j5desc").innerHTML="Haze";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='22') {document.getElementById("j5desc").innerHTML="Smoky";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='23') {document.getElementById("j5desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='24') {document.getElementById("j5desc").innerHTML="Blustery";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='25') {document.getElementById("j5desc").innerHTML="Cold";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='26') {document.getElementById("j5desc").innerHTML="Cloudy";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='27') {document.getElementById("j5desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='28') {document.getElementById("j5desc").innerHTML="Mostly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='29') {document.getElementById("j5desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='30') {document.getElementById("j5desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='31') {document.getElementById("j5desc").innerHTML="Clear";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='32') {document.getElementById("j5desc").innerHTML="Sunny";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='33') {document.getElementById("j5desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='34') {document.getElementById("j5desc").innerHTML="Fair";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='35') {document.getElementById("j5desc").innerHTML="Mixed rain and hail";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='36') {document.getElementById("j5desc").innerHTML="Hot";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='37') {document.getElementById("j5desc").innerHTML="Isolated thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='38') {document.getElementById("j5desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='39') {document.getElementById("j5desc").innerHTML="Scattered thunderstorms";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='40') {document.getElementById("j5desc").innerHTML="Scattered showers";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='41') {document.getElementById("j5desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='42') {document.getElementById("j5desc").innerHTML="Scattered snow showers";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='43') {document.getElementById("j5desc").innerHTML="Heavy snow";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='44') {document.getElementById("j5desc").innerHTML="Partly cloudy";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='45') {document.getElementById("j5desc").innerHTML="Thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='46') {document.getElementById("j5desc").innerHTML="Snow showers";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='47') {document.getElementById("j5desc").innerHTML="Isolated thundershowers";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='3200') {document.getElementById("j5desc").innerHTML="Not available";}
/*-- ICONE 1 ----------*/
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='0') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/0.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='1') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/1.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='2') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/2.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='3') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/3.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='4') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/4.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='5') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/5.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='6') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/6.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='7') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/7.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='8') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/8.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='9') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/9.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='10') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/10.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='11') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/11.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='12') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/12.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='13') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/13.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='14') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/14.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='15') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/15.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='16') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/16.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='17') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/17.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='18') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/18.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='19') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/19.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='20') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/20.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='21') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/21.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='22') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/22.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='23') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/23.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='24') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/24.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='25') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/25.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='26') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/26.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='27') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/27.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='28') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/28.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='29') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/29.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='30') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/30.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='31') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/31.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='32') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/32.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='33') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/33.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='34') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/34.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='35') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/35.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='36') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/36.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='37') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/37.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='38') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/38.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='39') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/39.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='40') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/40.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='41') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/41.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='42') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/42.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='43') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/43.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='44') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/44.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='45') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/45.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='46') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/46.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='47') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/47.png\">";}
if (xmlDoc.getElementsByTagName("integer")[22].childNodes[0].nodeValue =='3200') {document.getElementById("j5icon").innerHTML="<img class\=miniicone src=\"Library/Images/Icones/Petites/no.png\">";}
/*---------------------------------------------------------------------- FIN -----------------------------------------------------------------*/
}
