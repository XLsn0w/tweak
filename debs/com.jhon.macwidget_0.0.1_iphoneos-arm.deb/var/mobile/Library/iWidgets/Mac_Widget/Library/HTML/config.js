// Saisissez l'adresse de votre Flux RSS
var rssAddress = 'http://feeds.feedburner.com/iphone4fr';
// Mise à jour toutes les X minutes.
var updateInterval = 15;
// Tentative de mise à jour lorsque vous ne disposez pas d'une connexion internet.
var updateIntervalOff = 15;



// NE PAS EDITER !!!
var ShowPI = false;
// Limite du nombre de caractères affichés.
var LimitLetters = 250;
// Speical support for hebrew (if your main language is hebrew -> true, else -> false)
var hebrew = false;
// Do you want the widget to be right to left? (yes -> true, no -> false)
var rtl = false;