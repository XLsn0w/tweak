function init3 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("clock").appendChild ( timeDisplay );
}
function heure2 ( )
{
  var currentTime = new Date ( );
  var currentHours = currentTime.getHours ( );
  var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( );
  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
	var currentTimeString = currentHours + ":" + currentMinutes;
	var currentSecondsString = ":" + currentSeconds;
  document.getElementById("heure2").firstChild.nodeValue = currentTimeString;
  document.getElementById("secondes2").firstChild.nodeValue = currentSecondsString;
}
function amPm2 ( )
{
var currentTime = new Date ( );
var currentHours = currentTime.getHours ( );
  currentHours = currentHours + tz1h;  
  currentHours = ( currentHours < 0 ) ? currentHours + 24 : currentHours;
  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
  var currentTimeString = timeOfDay;
  document.getElementById("ampm").firstChild.nodeValue = currentTimeString;
}
function calendrier2 ( )
{
var this_date_name_array = new Array (" 0", " 1", " 2", " 3", " 4", " 5", " 6", " 7", " 8", " 9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23 "," 24 "," 25 "," 26 "," 27 "," 28 "," 29 "," 30 "," 31 ")
var this_weekday_name_array = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var this_month_name_array = new Array(" January"," February"," March"," April"," May"," June"," July"," August"," September"," October"," November"," December.")      //predefine month names
var this_date_timestamp = new Date()	  
var this_weekday = this_date_timestamp.getDay()    
var this_date = this_date_timestamp.getDate()    
var this_month = this_date_timestamp.getMonth()
var this_year = this_date_timestamp.getYear()
if (this_year < 1000)
	this_year+= 1900;
if (this_year==101)
	this_year=2001;
var month = this_date_timestamp.getMonth();
document.getElementById("ans2").firstChild.nodeValue = this_year
document.getElementById("mois2").firstChild.nodeValue = this_month_name_array[this_month]
document.getElementById("jour2").firstChild.nodeValue = this_weekday_name_array[this_weekday]
document.getElementById("journum2").firstChild.nodeValue = this_date_name_array[this_date]
function onPumpRefreshStart(data, settings) {
   $(".updateInd").removeClass("off");
}
function onPumpRefreshEnd(data, settings) {
   setTimeout(function () { $(".updateInd").addClass("off"); }, 500);
   var temp = parseInt(data.cc.temp, 10);
   if (!isNaN(temp)) {
      var high = data.forecast.day[0].high;
      if (isNaN(high)) high = temp + 10;
      var low = data.forecast.day[0].low;
      if (isNaN(low)) low = temp - 10;
      var left = ((150 / Math.max((high - low), 1)) * (temp - low)) - 16;
      left = Math.min(Math.max(left, -16), 136);
      $("#weather .current").css("left", left);
   }
   var d = new Date();
   var daysinmonth = 32 - new Date(d.getFullYear(), d.getMonth(), 32).getDate();
   var monthday = d.getDate();
   var left = ((150 / daysinmonth) * monthday) - 20;
   $("#calendar .day").css("left", left);
}
}