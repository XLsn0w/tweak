$(document).ready(function() {
//ELEMENTS MASQUES
$("#secondes").hide();$("#ville2").hide();$("#actudesc2").hide();$("#actumax2").hide();$("#actumin2").hide();$("#journum").hide();$("#mois").hide();$("#ans").hide();
// Départ
$("#content1").show();$("#content2").hide();$("#content3").hide();$("#content4").hide();$("#content5").hide();
// Folder1
$("#folder1").click(function(){$("#folder1").hide();$("#folder2").hide();$("#folder3").hide();$("#folder4").hide();$("#content2").show();$("#flechegauche").removeClass("flecheoff").addClass("flecheon");});
// Folder2
$("#folder2").click(function(){$("#folder1").hide();$("#folder2").hide();$("#folder3").hide();$("#folder4").hide();$("#content3").show();$("#flechegauche").removeClass("flecheoff").addClass("flecheon");});
// Folder3
$("#folder3").click(function(){$("#folder1").hide();$("#folder2").hide();$("#folder3").hide();$("#folder4").hide();$("#content4").show();$("#flechegauche").removeClass("flecheoff").addClass("flecheon");});
// Folder4
$("#folder4").click(function(){$("#folder1").hide();$("#folder2").hide();$("#folder3").hide();$("#folder4").hide();$("#content5").show();$("#flechegauche").removeClass("flecheoff").addClass("flecheon");});
// RETOUR
$("#boutonretour").click(function(){$("#folder1").show();$("#folder2").show();$("#folder3").show();$("#folder4").show();$("#content2").hide();$("#content3").hide();$("#content4").hide();$("#content5").hide();$("#flechegauche").removeClass("flecheon").addClass("flecheoff");});});;