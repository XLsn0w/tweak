﻿$(document).ready(function () {
      $("#up").click(function () {
         $("#viewport2").scrollTop($("#viewport2").scrollTop() + $("#viewport2").height());
      });
      $("#down").click(function () {
         $("#viewport2").scrollTop($("#viewport2").scrollTop() - $("#viewport2").height());
      });
});
function onPumpRefreshStart(data, settings) {
   $(".updateInd").removeClass("off");
}
function onPumpRefreshEnd(data, settings) {
setTimeout(function () { $(".updateInd").addClass("off"); }, 500);
 var temp = parseInt(data.cc.temp, 10);
   if (!isNaN(temp)) {
      var high = data.forecast.day[0].high;
      if (isNaN(high)) high = temp + 10;
      var low = data.forecast.day[0].low;
      if (isNaN(low)) low = temp - 10;
      var left = ((150 / Math.max((high - low), 1)) * (temp - low)) - 16;
      left = Math.min(Math.max(left, -16), 136);
      $("#weather .current").css("left", left);
   }
var d = new Date();
   var daysinmonth = 32 - new Date(d.getFullYear(), d.getMonth(), 32).getDate();
   var monthday = d.getDate();
   var left = ((150 / daysinmonth) * monthday) - 20;
   $("#calendar .day").css("left", left);
}
